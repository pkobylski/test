﻿using Sg.Configuration;
using Sg.Security.Crypto.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace Sg.ServiceAggregator
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            ConfigHelper.EncryptConnectionStrings();
            SecurityHelper.EncryptValuesInAppConfig("SgApiExternalKey");
            ServiceBase.Run(new ServiceAggregatorService());
        }
    }
}
