﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SgStacjaLib.Klasy
{
    public delegate void DZamknijFormularz();   // wykorzystywany w formularzu platnosci w kasie
    public delegate void DPrzeslijKlawisz(Keys klawisz);
    public delegate void DZmienBiezacyRekord(object biezacy);
    public delegate void DUstawieniaStartowe();
    public delegate void KatalogTowarowKasa();
    public delegate void ZamknijDialogPep();
    public delegate void OnOffSPS(bool onOff);
    public delegate void OnOffNotificationPageMM(bool onOff);
    public delegate void OnAdvicePZPageChange(bool approved, bool onOff);
    public delegate void WasDocumentPositionAmountEdited(bool edited);


    public class DeklaracjaDelegatow
    {
    }
}
