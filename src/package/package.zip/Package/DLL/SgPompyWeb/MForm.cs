﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using SgPompyKontroller;
using SgPompyCommon.KlasyPomocnicze;
using SgPompyCommon.Narzedzia;
using SgPompyDll;

namespace SgPompyApp
{
    public partial class MForm : DevExpress.XtraEditors.XtraForm
    {
        public MForm()
        {
            InitializeComponent();
        }


        private void MForm_Load(object sender, EventArgs e)
        {
            PompyDefinicje.UstawOrientacjeDystrybutorow(Orientation.Horizontal, DevExpress.Utils.HorzAlignment.Near, DevExpress.Utils.VertAlignment.Top);
            PompyReturn oPompyReturn = SgPompyAutomatController.InitAll(PanelDystrybutorow);

            SgPompyAutomatController.dKillYourself = new KillYourself(ZamknijApp);

            if (oPompyReturn.retv != 0)
            {
                MessageBox.Show(string.Format("Nieudane uruchomienie serwera pomp!\r\n{0}", oPompyReturn.Komunikat));
                this.Close();
            }
            PokazOpcje();
        }


        public void DClick(int nr)
        {
            OdblokujDystrybutor(nr);
        }

        void ZamknijApp()
        {
            this.Invoke(new MethodInvoker(this.Close));
        }
        

        private void MForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            SgPompyAutomatController.ZabijWszystkieWatki();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            PokazOpcje();
        }

        void SciagnijNalanie(int nrDystr)
        {
            DateTime dtStart = DateTime.Now;
            PompyDystrybutor oPompyDystrybutor =PompyDefinicje.LDystrybutorow.Where(x => x.DystrybutorNumerWSterowniku == nrDystr).FirstOrDefault();
            PompyReturn oPompyReturn = new PompyReturn();

            if (oPompyReturn.retv != 0)
            {
                if (oPompyReturn.KomunikatOgolny.Length > 0)
                    MessageBox.Show(oPompyReturn.KomunikatOgolny);
                return;
            }
            if (oPompyReturn.retv != 0)
                if (oPompyReturn.KomunikatOgolny.Length > 0)
                    MessageBox.Show(oPompyReturn.KomunikatOgolny);
            MessageBox.Show((DateTime.Now - dtStart).TotalMilliseconds.ToString());
        }

        private void OdblokujDystrybutor(int nrDystr)
        {
            PompyDystrybutor oPompyDystrybutor = PompyDefinicje.LDystrybutorow.Where(x => x.DystrybutorNumerWSterowniku == nrDystr).FirstOrDefault();

            PompyReturn oPompyReturn = new PompyReturn();

            if (oPompyReturn.retv != 0)
                if (oPompyReturn.KomunikatOgolny.Length > 0)
                    MessageBox.Show(oPompyReturn.KomunikatOgolny);
        }

        private void bPoziomo_Click(object sender, EventArgs e)
        {
            PompyDefinicje.UstawOrientacjeDystrybutorow(Orientation.Horizontal, DevExpress.Utils.HorzAlignment.Near, DevExpress.Utils.VertAlignment.Top);
            PanelDystrybutorow.BringToFront();
        }

        private void bPionowo_Click(object sender, EventArgs e)
        {
            PompyDefinicje.UstawOrientacjeDystrybutorow(Orientation.Vertical, DevExpress.Utils.HorzAlignment.Far, DevExpress.Utils.VertAlignment.Top);
            PanelDystrybutorow.Width = 400;
            PanelDystrybutorow.SendToBack();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
        }


        void PokazOpcje()
        {
            foreach (Control c in groupControl1.Controls)
            {
                if (c != simpleButton1)
                    c.Visible = !c.Visible;
            }
        }
    }
}