﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SgStacjaLib.Klasy
{

    public static class FunkcjeZnakowe
    {
        public static void ZamienZnak(ref string we, char oldChar, char newChar)
        {
            we.Replace(oldChar, newChar);
        }
        public static string ZamienZnak(string we, char oldChar, char newChar)
        {
            string bf = we;
            bf = we.Replace(oldChar, newChar);
            return bf;
        }

        public static string TylkoLiteryCyfry(string we)
        {
            string wy = "";
            if (we == null)
                return "";
            for (int i = 0; i < we.Length; i++)
            {
                if (char.IsLetterOrDigit(we[i]))
                    wy += we[i];
            }
            return wy;
        }
        public static string TylkoLiteryCyfrySPL(string we)
        {
            string wy = "";
            if (we == null)
                return "";
            for (int i = 0; i < we.Length; i++)
            {
                if (we[i] == '_')
                    continue;
                if (char.IsLetterOrDigit(we[i]))
                    wy += we[i];
                if (we[i] == '+')
                    wy += we[i];
            }
            return wy;
        }

        public static string WypelnijZnakiem(int liczba, int dlugosc, char znak, bool zprzodu)
        {
            string bf = "", sLiczba = liczba.ToString();
            if (zprzodu)
            {
                for (int i = 0; i < (dlugosc - sLiczba.Length); i++)
                {
                    bf += znak;
                }

                bf += sLiczba;
            }
            else
            {
                bf += sLiczba;
                for (int i = sLiczba.Length; i < dlugosc; i++)
                {
                    bf += znak;
                }
            }
            return bf;

        }

        public static string WypelnijZnakiem(string bk, int dlugosc, char znak, bool zprzodu)
        {
            string bf = "";
            if (zprzodu)
            {
                for (int i = 0; i < dlugosc - (bk.Length); i++)
                {
                    bf += znak;
                }
                bf += bk;
            }
            else
            {
                bf += bk;
                for (int i = bk.Length; i < dlugosc; i++)
                {
                    bf += znak;
                }

            }
            return bf;

        }
        public static string ZamienPolskieZnaki(string wyraz)
        {
            string nowy = "";

            for (int i = 0; i < wyraz.Length; i++)
            {
                switch (wyraz[i])
                {
                    case 'ą':
                        nowy += 'a';
                        break;
                    case 'ś':
                        nowy += 's';
                        break;
                    case 'ż':
                        nowy += 'z';
                        break;
                    case 'ź':
                        nowy += 'z';
                        break;
                    case 'ć':
                        nowy += 'c';
                        break;
                    case 'ę':
                        nowy += 'e';
                        break;
                    case 'ń':
                        nowy += 'n';
                        break;
                    case 'ł':
                        nowy += 'l';
                        break;
                    case 'ó':
                        nowy += 'o';
                        break;
                    case 'Ą':
                        nowy += 'A';
                        break;
                    case 'Ś':
                        nowy += 'S';
                        break;
                    case 'Ż':
                        nowy += 'Z';
                        break;
                    case 'Ź':
                        nowy += 'Z';
                        break;
                    case 'Ć':
                        nowy += 'C';
                        break;
                    case 'Ę':
                        nowy += 'E';
                        break;
                    case 'Ń':
                        nowy += 'N';
                        break;
                    case 'Ł':
                        nowy += 'L';
                        break;
                    case 'Ó':
                        nowy += 'O';
                        break;

                    default:
                        nowy += wyraz[i];
                        break;
                }
            }
            return nowy;
        }
        public static string SymbolWalutyPepHex(string symbol)
        {
            string bf = symbol;
            string walutaSymbol = "";


            if (bf.Length != 6)
            {
                walutaSymbol = "??";
                return walutaSymbol;
            }
            for (int i = 0; i < 3; i++)
            {
                string znakHex = "";
                for (int k = 0; k < 2; k++)
                {
                    znakHex += bf[i * 2 + k];
                }
                int hex = int.Parse(znakHex, System.Globalization.NumberStyles.HexNumber);
                walutaSymbol += (char)hex;
            }
            return walutaSymbol;
        }
        public static string ZamienNaStringPepHex(string symbol)
        {
            string bf = symbol;
            string walutaSymbol = "";
            int dl = symbol.Length - 1;


            if (bf == null || bf.Length == 0)
            {
                walutaSymbol = "??";
                return walutaSymbol;
            }
            for (int i = 0; i <= dl / 2; i++)
            {
                string znakHex = "";
                for (int k = 0; k < 2; k++)
                {
                    if ((i * 2 + k) < bf.Length)
                        znakHex += bf[i * 2 + k];
                }
                int hex = int.Parse(znakHex, System.Globalization.NumberStyles.HexNumber);
                walutaSymbol += (char)hex;
            }
            return walutaSymbol;
        }
        public static string UsunCzescDziesietna(string liczba)
        {
            return "";
        }
        public static string KodeDokumentu(int transakcjaId, int fakturaId)
        {
            string wynik = "";
            if (!GlobalneParametry.Current.oPunktH.pkt_nr.HasValue)
                GlobalneParametry.Current.oPunktH.pkt_nr = 0;
            wynik = WypelnijZnakiem((int)GlobalneParametry.Current.oPunktH.pkt_nr, 4, '0', true);
            wynik += WypelnijZnakiem(transakcjaId, 10, '0', true);
            wynik += WypelnijZnakiem(fakturaId, 10, '0', true);
            return wynik;
        }
    }
}
