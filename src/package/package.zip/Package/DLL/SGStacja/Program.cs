﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using DevExpress.LookAndFeel;
using System.Data;
using System.Linq;
using SgKatalog.Klasa;
using SgStacjaDomain.Lib;
using System.Threading;
using System.Diagnostics;
using SgStacjaListy.Klasa;
using System.Configuration;
using DevExpress.XtraEditors;
using SgStacjaDomain.ZmienneGlobalne;
using SG.StacjaKokpit.Forms;
using SgKasaParagon.Klasa;
using System.Reflection;
using SgStacjaLib.Klasy.Iban;
using SgKasaParagon.WidokJedenRekord;
using Sg.Security.Crypto;
using SGBStacjaMapping;
using Sg.Configuration;
using SgKatalog.Katalog;
using SgStacjaLib.Klasy;
using Sg.Services.Health;
using Sg.Security.Crypto.Controller;
using SgStacjaDomain.SprzedazPonizejStanu;

namespace SgKasa
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ConfigHelper.EncryptConnectionStrings();
            SecurityHelper.EncryptValuesInAppConfig("SgApiExternalKey");
            InDatabaseConfiguration.Initialize(new Action<Exception>(ex => ZdarzeniePlik.UnhandledError(ex)));

            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            LoadingScreen.ShowLoadingScreen("SgKasa");

            Application.EnableVisualStyles();

            DevExpress.Skins.SkinManager.EnableFormSkins();
            DevExpress.UserSkins.BonusSkins.Register();
            UserLookAndFeel.Default.SetSkinStyle("DevExpress Style");

            DevExpress.UserSkins.BonusSkins.Register();
            DevExpress.Skins.SkinManager.EnableFormSkins();
            Application.EnableVisualStyles();
            DevExpress.Skins.SkinManager.EnableFormSkinsIfNotVista();
            SgStacjaAktualizacje.Aktualizacje aktualizacje = null;

            #region Parametry domyślne
            GlobalneParametry.Current.ZAKRES_KRW = ZakresKRW.BrakOgraniczen;
            #endregion

            GlobalneParametry.Current.oBiezacyModul = EnModulStacjePaliw.SgKasa;
            GlobalneParametry.Current.WysokoscStatus = 60;

            Application.ThreadException += new ThreadExceptionEventHandler(ProgramWyjatek.OnThreadException);

            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(ProgramWyjatek.UnhandledException);


            GlobalneParametry.Current.AplikacjaMdi = false;
            GlobalneParametry.Current.raportGrupyGlowne = true;

            
            IbanStructures.Load();

            SgStacjaAktualizacje.Aktualizacje.RunActualization(true, ref aktualizacje, "SgKasa");

            using (var mutex = new Mutex(true, "SgKasaProgram"))
            {
                KasaManager oKasaManager = null;
                if (!mutex.WaitOne(TimeSpan.FromSeconds(2), false))
                {
                    SgKomunikat.Uwaga("Program SgKasa jest juz uruchomiony!", KomunikatTyp.Blad);
                    return;
                }
                try
                {

                    Logowanie oLogin = new Logowanie();
                    if (oLogin.Zaloguj())
                    {

                        var dbBazaSgbStacjaStanyRok = new SGBStacjaStanyRokContext();
                        dbBazaSgbStacjaStanyRok = null;

                        SgStacjaAktualizacje.Aktualizacje.RunActualization(GlobalneParametry.Current.UruchomAktualizacje, ref aktualizacje, "SgKasa");

                        StartHealthJob.Start(
                            ConfigurationManager.AppSettings["SgApiExternalUrl"],
                            SecurityHelper.DecryptValue(ConfigurationManager.AppSettings["SgApiExternalKey"]),
                            GlobalneParametry.Current.oPunktH.pkt_nr.ToString(),
                            int.Parse(ConfigurationManager.AppSettings["Stanowisko"]));

                        if ((StacjaStanowiskoEkran)GlobalneParametry.Current.oStanowisko.ekran != StacjaStanowiskoEkran.Professional &&
                            (StacjaStanowiskoEkran)GlobalneParametry.Current.oStanowisko.ekran != StacjaStanowiskoEkran.Dotykowy)
                            GlobalneParametry.Current.oStanowisko.ekran = (int)StacjaStanowiskoEkran.Professional;
                        SprzedazPS oSprzedazPS = new SprzedazPS();
                        oSprzedazPS.ZaleglePartieDoZbilansowania(true, false);

                        switch ((StacjaStanowiskoEkran)GlobalneParametry.Current.oStanowisko.ekran)
                        {
                            case StacjaStanowiskoEkran.Nieokreslone:
                            case StacjaStanowiskoEkran.Podstawowy:
                                SgKomunikat.NowyKomunikat(true);
                                frmKasa oMain = new frmKasa();
                                if (!oMain.jestOK)
                                {
                                    oMain.Close();
                                    return;
                                }
                                oMain.Name = GlobalneParametry.Current.nazwaFormularza("frmKasa");
                                GlobalneParametry.Current.kasaEkran = oMain;
                                try
                                {
                                    KonfiguratorIni.UstawSkin();
                                    Application.Run(oMain);
                                }
                                finally
                                {
                                    if (GlobalnaTransakcja.oSgPersonelLog != null)
                                        GlobalnaTransakcja.oSgPersonelLog.Wyloguj(SeLogin.Wylogowany, "Kasa wylogowanie");
                                }

                                break;
                            case StacjaStanowiskoEkran.Dotykowy:
                            case StacjaStanowiskoEkran.Professional:
                                SgKomunikat.NowyKomunikat(true);
                                FrmPanelGlowny oFrmPanelGlowny = new FrmPanelGlowny();
                                WindowsFormsSettings.TouchUIMode = TouchUIMode.True;
                                WindowsFormsSettings.ScrollUIMode = ScrollUIMode.Touch;
                                GlobalneParametry.Current.kasaEkran = oFrmPanelGlowny;
                                try
                                {
                                    if ((StacjaStanowiskoEkran)GlobalneParametry.Current.oStanowisko.ekran == StacjaStanowiskoEkran.Professional)
                                        oFrmPanelGlowny.WindowState = FormWindowState.Maximized;
                                    oKasaManager = new KasaManager();
                                    KonfiguratorIni.UstawSkin();
                                    GlobalneParametry.Current.oImageColection32 = oFrmPanelGlowny.oImageCollection;
                                    if (!oKasaManager.UruchomKasePro())
                                        return;

                                    Application.Run(oFrmPanelGlowny);
                                }
                                finally
                                {
                                    if (GlobalnaTransakcja.oSgPersonelLog != null)
                                        GlobalnaTransakcja.oSgPersonelLog.Wyloguj(SeLogin.Wylogowany, "Kasa wylogowanie, sekcja finally");
                                    if (GlobalneParametry.Current.JestAutomatyka)
                                    {
                                        try
                                        {
                                            SgPompyKontroller.SgPompyKasaController.ZabijWszystkieWatki();
                                        }
                                        finally
                                        {
                                            SgKomunikat.InfoStop();
                                        }
                                    }
                                }
                                break;
                        }
                    }
                }
                finally
                {
                    if (GlobalneParametry.Current.UruchomAktualizacje && aktualizacje != null)
                    {
                        aktualizacje.Abort();
                    }
                    if (GlobalneParametry.Current.oWatekFiskalnyPdtGlowny != null)
                        GlobalneParametry.Current.oWatekFiskalnyPdtGlowny.Dispose();
                    if (GlobalneParametry.Current.oWatekFiskalnyPdtAnwim != null)
                        GlobalneParametry.Current.oWatekFiskalnyPdtAnwim.Dispose();
                    oKasaManager?.Dispose();
                    mutex.ReleaseMutex();
                }
            }
        }
    }
}